require "libs.all"

require "prototypes.belt-sorter-items"
require "prototypes.belt-sorter-recipes"
require "prototypes.belt-sorter-entities"
require "prototypes.belt-sorter-technologies"

require "prototypes.everything-else-filter-item"
require "prototypes.belt-sorter-config-combinator"