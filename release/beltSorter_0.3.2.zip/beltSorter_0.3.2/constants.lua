
modVersion = "0.3.1"
modName = "beltSorter" -- required prefix for all ui name components which can be clicked
fullModName = "beltSorter" -- required for logging and prototypes


beltSorterLog.testing = false -- enables player printing of every log, sets log level to info
