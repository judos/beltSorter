require "prototypes.belt-sorter-prototypes"

for i=4,5 do
	createBeltSorterItemPrototype(i)
end