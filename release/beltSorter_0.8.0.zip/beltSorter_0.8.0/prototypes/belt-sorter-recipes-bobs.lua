data:extend({
	{
		type = "recipe",
		name = "belt-sorter4",
		enabled = false,
		ingredients = {
			{"belt-sorter3", 1},
			{"advanced-circuit", 4},
			{"processing-unit", 4}
		},
		result = "belt-sorter4"
	},
	{
		type = "recipe",
		name = "belt-sorter5",
		enabled = false,
		ingredients = {
			{"belt-sorter4", 1},
			{"advanced-circuit", 8},
			{"processing-unit", 8}
		},
		result = "belt-sorter5"
	}
})