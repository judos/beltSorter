require "prototypes.belt-sorter-prototypes"

for i=1,3 do
	createBeltSorterItemPrototype(i)
end