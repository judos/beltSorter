
data:extend(
{
	{
		type = "bool-setting",
		name = "beltSorter-usePower",
		setting_type = "startup",
		order = "a1",
		default_value = true,
	}
})

