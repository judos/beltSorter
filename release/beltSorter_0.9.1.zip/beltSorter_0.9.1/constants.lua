modVersion = "0.8.1" --version of control data, only updated when control.lua data handling changes in a major way
modName = "beltSorter" -- required prefix for all ui name components which can be clicked
fullModName = "beltSorter" -- required for logging and prototypes


logging.debug_master = true
--logging.testing = true -- enables player printing of every log, sets log level to info
--logging.debug_level = 1  -- 1=info 2=warn 3=error
