
require "libs.prototypes.recipe"
require "libs.prototypes.technology"
require "libs.prototypes.prototypes"
require "libs.prototypes.recipeCategories"
require "libs.prototypes.resources"
require "libs.prototypes.entityCategory"
require "libs.prototypes.entity"